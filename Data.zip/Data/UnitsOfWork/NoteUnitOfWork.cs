﻿using AutoMapper;
using Premier.API.Core.Data.Repositories;
using Premier.API.ERPNA.Notes.Data.Contexts;
using Premier.API.ERPNA.Notes.Data.Entity;
using Premier.API.ERPNA.Notes.Data.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Premier.API.ERPNA.Notes.Data.UnitsOfWork
{

    public class NoteUnitOfWork : UnitOfWork
    {
        private readonly ApplicationDbContext _context;
        public NoteRepository _noteRepository { get; }

        public NoteUnitOfWork(
            ApplicationDbContext context,
            NoteRepository noteRepository
        ) : base(context)
        {
            _context = context;
            _noteRepository = noteRepository;
        }
    }
}
