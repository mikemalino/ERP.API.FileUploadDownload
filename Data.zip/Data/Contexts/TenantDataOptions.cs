﻿namespace Premier.API.ERPNA.Notes.Data.Contexts
{
    using Premier.API.Core.Data.Contexts;

    public class TenantDataOptions : BaseProviderOptions
    {
    }
}
