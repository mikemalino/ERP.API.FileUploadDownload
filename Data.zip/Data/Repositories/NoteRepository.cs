﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;

using Premier.CommonData.ERPNA.Data.Repository;

using Premier.API.Core.Data.Repositories;
using Premier.API.ERPNA.Notes.Data.Contexts;
using Premier.API.ERPNA.Notes.Data.Entity;
using Premier.API.ERPNA.Notes.DTO.Response;
using Premier.API.ERPNA.Notes.DTO.Request;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System;
using System.Linq.Expressions;

namespace Premier.API.ERPNA.Notes.Data.Repositories
{
    public class NoteRepository : GenericRepository<Note>
    {
        public NoteRefRepository _noteRefRepo { get; }

        protected readonly IERPNACommonDataLookup _erpNACommonDataLookup;

        public NoteRepository(ApplicationDbContext context, IMapper mapper, NoteRefRepository noteRefRepo, IERPNACommonDataLookup erpNACommonDataLookup) : base(context, mapper)
        {
            _noteRefRepo = noteRefRepo;
            _erpNACommonDataLookup = erpNACommonDataLookup;
        }

        #region Note CRUD Operations

        public EntityEntry InsertNote(NoteInsertRequest noteInsertRequest)
        {
            Note item = _mapper.Map<Note>(noteInsertRequest);
            item.NoteDate = DateTime.UtcNow;
            item.NoteRefs.Add(new NoteRef() { RefEntityId = noteInsertRequest.EntityID, RefType = noteInsertRequest.EntityType });
            return this.Insert(item);
        }

        public void UpdateNoteText(NoteUpdateRequest noteUpdateRequest)
        {
            var Fields = new Expression<Func<Note, object>>[]
            {
                i => i.NoteText
            };

            Note item = _mapper.Map<Note>(noteUpdateRequest);
            
            /*
            Note item = this.GetByPK(noteUpdateRequest.NoteID);// _mapper.Map<Note>(noteUpdateRequest);
            item.NoteText = noteUpdateRequest.NoteText;
            */

            this.UpdateFields(item, Fields);
        }

        public IEnumerable<TResult> GetSavedEntities<TResult>()
        {
            var entitiesSaved = this._GetSavedEntities();
            return _mapper.Map<List<TResult>>(entitiesSaved);
        }

        #endregion

        #region IQueryable notes

        public IQueryable<NoteRecordResponse> qNoteRecordResponse(int entityID, int entityType)
        {
            var query = _noteRefRepo.Where(i => i.RefEntityId == entityID && i.RefType == entityType)
                .Join(_dbSet,
                    nref => nref.NoteId,
                    note => note.Id,
                    (nref, note) => new NoteRecordResponse(note)
               );

            return query;
        }

        #endregion

        /*
        public EntityEntry InsertNotespingCart(NotespingCart cart)
        {
            var entityResult = this.Insert(cart);
            return entityResult;
        }

        public async Task<EntityEntry> UpdateNotespingCart(NotespingCartUpdateRequest request)
        {
            var entityResult = await this.UpdateAsync(_mapper.Map<NotespingCart>(request));
            return entityResult;
        }

        public IEnumerable<TResult> GetSavedEntities<TResult>()
        {
            var entitiesSaved = this._GetSavedEntities();
            return _mapper.Map<List<TResult>>(entitiesSaved);
        }

        public void DeleteCart(int cartID)
        {
            this._scLineRepo.RemoveRange(this._scLineRepo.Where(i => i.NotespingCartId == cartID));
            this.Remove(cartID);
        }
        */
    }
}
