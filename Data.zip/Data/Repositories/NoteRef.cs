﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;

using Premier.CommonData.ERPNA.Data.Repository;

using Premier.API.Core.Data.Repositories;
using Premier.API.ERPNA.Notes.Data.Contexts;
using Premier.API.ERPNA.Notes.Data.Entity;
using Premier.API.ERPNA.Notes.DTO.Response;
using Premier.API.ERPNA.Notes.DTO.Request;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Premier.API.ERPNA.Notes.Data.Repositories
{
    public class NoteRefRepository : GenericRepository<NoteRef>
    {
        protected readonly IERPNACommonDataLookup _erpNACommonDataLookup;

        public NoteRefRepository(ApplicationDbContext context, IMapper mapper, IERPNACommonDataLookup erpNACommonDataLookup) : base(context, mapper)
        {
            _erpNACommonDataLookup = erpNACommonDataLookup;
        }
    }
}
