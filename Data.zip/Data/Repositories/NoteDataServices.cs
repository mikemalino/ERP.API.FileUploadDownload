﻿using AutoMapper;

using Premier.API.ERPNA.Notes.Data.Contexts;
using Premier.API.Core.Data.DataServices;
using System.Linq;
using Premier.API.ERPNA.Notes.DTO.Response;

namespace Premier.API.ERPNA.Notes.Data.Repositories
{
    public class NoteDataServices : DataServices
    {
        public NoteDataServices(ApplicationDbContext context, IMapper mapper) : base(context)
        {
        }
    }
}
