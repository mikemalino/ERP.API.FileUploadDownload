﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Premier.API.ERPNA.Notes.Data.Entity
{
    public class DataEntityPlaceHolder
    {
    }
}
