﻿using Premier.API.Core.Contracts;
using System;
using System.Collections.Generic;

#nullable disable

namespace Premier.API.ERPNA.Notes.Data.Entity
{
    public partial class NoteRef : IEntity, ICreateUserWithId, IModifiedUserWithId
    {
    }
}
